gfortran -o cscompqe cscompqe.f csfitcomp.f gsmearing.f qenuc21off.f mec2021.f vcoul.f sf.f formfacts.f rescsp.f resmodp.f rescsn.f resmodn.f nuccs12cs.f nucffs12c.f nucffs12ct.f nuc12sf.f 


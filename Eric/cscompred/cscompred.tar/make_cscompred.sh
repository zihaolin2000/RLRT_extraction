 gfortran -o cscompred cscompred.f f1f221v1.0.f nuccs12cs.f nucffs12c.f nucffs12ct.f -L/user/local/cern/2005/lib  -lc -lm


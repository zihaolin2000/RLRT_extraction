gfortran -o modplotred modplotred.f f1f221v1.0.f nuccs12cs.f nucffs12c.f nucffs12ct.f

